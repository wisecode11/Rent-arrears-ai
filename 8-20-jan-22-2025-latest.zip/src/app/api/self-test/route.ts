import { NextResponse } from 'next/server';
import { parseLedgerFromText, chargesFromLedgerEntries } from '@/lib/ledger-parser';
import { parsePDFTextDirectly } from '@/lib/huggingface-client';
import { calculateFinalAmount } from '@/lib/business-logic';
import type { HuggingFaceResponse } from '@/types';

export async function GET() {
  const fixtures: Array<{ name: string; asOfDate: string; text: string; issueDateISO?: string }> = [
    {
      name: 'Format A (simple 2-amount rows)',
      asOfDate: '2026-01-03', // 1st-5th => previous month balance
      text: `
12/01/2025 BASE RENT 1500.00 1500.00
12/01/2025 AIR CONDITIONER 10.00 1510.00
12/05/2025 PAYMENT -1510.00 0.00
01/01/2026 BASE RENT 1500.00 1500.00
01/02/2026 LATE FEE 25.00 1525.00
      `.trim(),
    },
    {
      name: 'Format B (debit/credit/balance rows)',
      asOfDate: '2026-01-19', // 6th+ => current month balance
      text: `
2025-12-01 Rent Charge 1500.00 0.00 1500.00
2025-12-02 Maintenance Fee 50.00 0.00 1550.00
2025-12-10 Payment 0.00 1550.00 0.00
2026-01-01 Rent 1500.00 0.00 1500.00
2026-01-03 Legal Fees 100.00 0.00 1600.00
      `.trim(),
    },
    {
      name: 'Format C (statement w/ charge codes + wrapped amount/balance)',
      asOfDate: '2026-01-19',
      text: `
DATE DESCRIPTION AMOUNT AMOUNT BALANCE
07/01/2015  1 BASE RENT : 1525.00
1525.00
07/01/2015 25 AIR CONDITIONER : 10.00 1535.00
07/23/2015 PAYMENT CH#:159 1525.00 10.00
08/01/2015  1 BASE RENT : 1525.00
1535.00
08/06/2015 59 LATE CHARGE : 25.00 1570.00
TOTAL  234345.71  228609.66    5736.05
      `.trim(),
    },
    {
      name: 'Balance-forward rows should NOT count as non-rental',
      asOfDate: '2026-01-19',
      text: `
12/01/2015 BASE RENT 1525.00 4675.00
12/01/2015 AIR CONDITIONER 10.00 4685.00
12/02/2015 PAYMENT -1525.00 3160.00
01/01/2016 YEAR STARTING BALANCE 2016 3160.00 3160.00
01/01/2016 AIR CONDITIONER 10.00 3170.00
      `.trim(),
    },
    {
      name: 'Issue Date cutoff (ignore future month entries)',
      asOfDate: '2026-01-03', // system date (should be ignored because issue date is present)
      issueDateISO: '2025-06-02',
      text: `
Date  Chg Code  Description  Charge  Payment  Balance  Chg/Rec
05/31/2025  latefee  Late Fee (05/2025)  50.00  0.00  100.00  1
06/01/2025  resid  Residential Rent (06/2025)  500.00  0.00  200.00  2
07/01/2025  resid  Residential Rent (07/2025)  500.00  0.00  300.00  3
      `.trim(),
    },
    {
      name: 'Issue Date + rent-only current month => step back',
      asOfDate: '2026-01-19',
      issueDateISO: '2025-08-14',
      text: `
Date  Chg Code  Description  Charge  Payment  Balance  Chg/Rec
08/01/2025  latefee  Late Fee (07/2025)  50.00  0.00  900.00  1
09/01/2025  resid  Residential Rent (09/2025)  1000.00  0.00  1500.00  2
      `.trim(),
    },
    {
      name: 'Issue Date + non-rent in current month => use it',
      asOfDate: '2026-01-19',
      issueDateISO: '2025-08-14',
      text: `
Date  Chg Code  Description  Charge  Payment  Balance  Chg/Rec
08/01/2025  latefee  Late Fee (07/2025)  50.00  0.00  900.00  1
09/01/2025  resid  Residential Rent (09/2025)  1000.00  0.00  1500.00  2
09/01/2025  latefee  Late Fee (08/2025)  50.00  0.00  1550.00  3
      `.trim(),
    },
  ];

  const results = fixtures.map((f) => {
    const parsed = parseLedgerFromText(f.text);
    const { rentalCharges, nonRentalCharges } = chargesFromLedgerEntries(parsed.ledgerEntries);
    const issueDate = f.issueDateISO;

    const aiData: HuggingFaceResponse = {
      tenantName: 'Test Tenant',
      propertyName: 'Test Property',
      period: 'Fixture',
      openingBalance: parsed.ledgerEntries[0]?.balance ?? 0,
      finalBalance: parsed.ledgerEntries.at(-1)?.balance ?? 0,
      rentalCharges,
      nonRentalCharges,
      ledgerEntries: parsed.ledgerEntries,
      issueDate,
    };

    const processed = calculateFinalAmount(aiData, new Date(f.asOfDate));
    const nonRentHasBalanceForward = nonRentalCharges.some((c) =>
      c.description.toUpperCase().includes('YEAR STARTING BALANCE')
    );
    return {
      name: f.name,
      asOfDate: f.asOfDate,
      ledgerEntries: parsed.ledgerEntries.length,
      rentalCharges: rentalCharges.length,
      nonRentalCharges: nonRentalCharges.length,
      nonRentHasBalanceForward,
      sampleRental: rentalCharges.slice(0, 3),
      latestBalance: processed.latestBalance,
      lastZeroOrNegativeBalanceDate: processed.lastZeroOrNegativeBalanceDate,
      totalNonRentalFromLastZero: processed.totalNonRentalFromLastZero,
      rentArrears: processed.rentArrears,
      calculationTrace: processed.calculationTrace,
      debugLedgerTail:
        f.name.startsWith('Issue Date')
          ? parsed.ledgerEntries.slice(-5)
          : undefined,
    };
  });

  const tenantLedgerFixtures: Array<{ name: string; asOfDate: string; text: string }> = [
    {
      name: 'Tenant Ledger (supports 1-digit dates + negative balances + late fees)',
      asOfDate: '2025-07-08',
      text: `
Tenants: Sarah Thomas
Unit: 938 Eastern Parkway - 2A
Property: 932-938 Eastern Parkway Residences, LLC - 932-938 Eastern Parkway Brooklyn, NY 11213
Date Payer Description Charges Payments Balance
0.00
Starting Balance
6/1/2020 Residential Rent - APT RENT 1,900.00 1,900.00
6/22/2020 Shekinah Voisin Payment 950.00 950.00
// concatenated tokens like some PDF extractions produce:
7/16/2023 Late Fees - Residential - Late Fee for Jul 202350.00532.36
9/20/2021 Shekinah Voisin Payment (Reference #DTZQ-3LYM) 16,150.00-3,800.00
8/1/2024 Residential Rent - August 2024 - Legal Rent2,050.921,492.12
Total 6,421.96
      `.trim(),
    },
  ];

  const tenantLedgerResults = tenantLedgerFixtures.map((f) => {
    const aiData = parsePDFTextDirectly(f.text);
    const processed = calculateFinalAmount(aiData as HuggingFaceResponse, new Date(f.asOfDate));
    return {
      name: f.name,
      asOfDate: f.asOfDate,
      ledgerEntries: aiData.ledgerEntries?.length ?? 0,
      rentalCharges: aiData.rentalCharges?.length ?? 0,
      nonRentalCharges: aiData.nonRentalCharges?.length ?? 0,
      lastZeroOrNegativeBalanceDate: processed.lastZeroOrNegativeBalanceDate,
      latestBalance: processed.latestBalance,
      totalNonRentalFromLastZero: processed.totalNonRentalFromLastZero,
      sampleNonRent: (aiData.nonRentalCharges ?? []).slice(0, 3),
      debugLedgerTail: (aiData.ledgerEntries ?? []).slice(-5),
    };
  });

  return NextResponse.json({ ok: true, results, tenantLedgerResults });
}




